<?php
session_start();
$host='localhost';
$username='root';
$password1='';
$database='chat';
$db=mysqli_connect($host,$username,$password1,$database);
if ($db) {
	//echo "Connected ";
}
