function send_message() {
	var sender_user=$("#session_id").val();
	var receiver_id=$("#receiver_id1").val();
	var message=$("#message_to_sent").val();
	//alert(sender_user+' '+receiver_id+' '+message)

	$.ajax({
		url:"php/send_message.php",
		type:"POST",
		data:{sender_user:sender_user, receiver_id:receiver_id, message:message},
		success:function() {
			
			$("#send_message_form").trigger("reset");
			load_messages();
			
		}
	});
}
