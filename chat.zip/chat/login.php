<!DOCTYPE html>
<html>
<head>
	<title>LogIn</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="style/style_login.css">
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
	
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
	<style type="text/css">
		small{
			color: red;
		}
		
		.form .form-group i{


}

	</style>
</head>
<body class="bg-info">
	
		<div class="container maindiv">
			<div class="login row shadow">
				
					<div class="col-sm-4 left-side bg-info">
						<div class="logo border">
								 <h1>ich<i class="fas fa-paper-plane"></i>t</h1>
							</div>
						<div class="content">
							
							<h1>Welcome User!</h1>
							<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam
							.</p>
							<div class="bottom">
							<button class="btn btn-outline-light button" id="signup3">Sign Up</button>
							<small style="color: white">If you don't have account</small>
						</div>
						</div>
					</div>
					<div class="col-sm-8 right-side " id="contentUpdate">
						<div class="row">
							<div class="col-sm-4">
								<h1 class="display-4">Sign In</h1>
							</div>
							<div class="col-sm-4">
								<a href="" id="signup1" style="color: lightgrey;text-decoration: none"><h1 style="color: lightgrey" class="display-4">Sign Up</h1></a>
							</div>
						</div>
						
						<hr>
						<div class="form">
							
								<p class="alert alert-danger" id="global_error" style="display:none">
									
								</p>
								
							<div class="form-group">
								<label>Mobile Number:</label><br>
								<i class="fas fa-phone-square bg-info text-white pb-3 pt-3 pl-3 pr-3 border" style="font-size: 24px" class=""></i><input type="text" name="" id="user_mobile" placeholder="Enter Mobile Number"><br>
								<small id="mobile_error"></small>
								<br><br>
								<label>Password:</label><br>
								<i class="fas fa-unlock-alt bg-info text-white pb-3 pt-3 pl-3 pr-3 border" style="font-size: 24px"></i><input type="password" name="" id="user_password" placeholder="Enter Password" ><br>
								<small id="password_error"></small>
								<br><br>
								<p><a href="#" style="color: #00aab0;" id="forget_password">Forget Password?</a></p>
								<button type="button" id="login">Sign In</button><br><br>
								<hr>
								<p><a href="" id="signup2" style="color: #00aab0">Sign Up</a> if you don't have account</p>
								
							</div>
						</div>
					</div>
					<div class="col-sm-8 right-side " id="contentSignin" style="display: none;">
						<div class="row">
							<div class="col-sm-4">
								<a href="" id="signin1" style="color: #00aab0;text-decoration: none"><h1 class="display-4" style="color: lightgrey">Sign In</h1></a>
							</div>
							<div class="col-sm-4">
								<h1 style="color: #00aab0" class="display-4">Sign Up</h1>
							</div>
						</div>
						
						<hr>
						<div class="form">
							<p class="alert alert-danger"  id="global_error2" style="display: none">
									
								</p>
							<div class="form-group">
								<label>First Name:</label><br>
								<i class="fas fa-user bg-info text-white pb-3 pt-3 pl-3 pr-3 border" style="font-size: 24px"></i><input type="text" name="" id="fname" placeholder="Enter First Name" ><br>
								<small id="fname_error"></small>
								<br><br>
								<label>Last Name:</label><br>
								<i class="fas fa-user bg-info text-white pb-3 pt-3 pl-3 pr-3 border" style="font-size: 24px"></i><input type="text" name="" id="lname" placeholder="Enter Last Name" ><br>
								<small id="lname_error"></small>
								<br><br>
								<label>Mobile Number:</label><br>
								<i class="fas fa-phone-square bg-info text-white pb-3 pt-3 pl-3 pr-3 border" style="font-size: 24px"></i><input type="text" name="" id="mobile" placeholder="Enter Mobile Number" ><br>
								<small id="mobile_error2"></small>
								<br><br>
								<label>Password:</label><br>
								<i class="fas fa-unlock-alt bg-info text-white pb-3 pt-3 pl-3 pr-3 border" style="font-size: 24px"></i><input type="password" name="" id="password" placeholder="Enter Password" ><br>
								<small id="password_error2"></small>
								<br><br>
								<label>Confirm Password:</label><br>
								<i class="fas fa-unlock-alt bg-info text-white pb-3 pt-3 pl-3 pr-3 border" style="font-size: 24px"></i><input type="password" name="" id="cpassword" placeholder="Confirm Password" ><br>
								<small id="cpassword_error"></small>
								<br><br>
								<button type="button" id="register">Sign Up</button><br><br>
								<hr>
								<p><a href="" id="signin2" style="color: #00aab0">Sign In</a> if you already have account</p>
								
							</div>

						</div>

					</div>
					<div class="modal fade" id="forget_modal">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header bg-info text-white">
									<h4 class="modal-title  p-3">Forget Password</h4>
									<button type="button" class="close" data-dismiss="modal">&times;</button>
								</div>
								<div class="modal-body " id="body">
									<p class="alert alert-danger"  id="forget_error" style="display: none"></p>
									<label>Enter Mobile Number:</label><br>
									<input type="text" name="" id="mobile_forget" placeholder="Enter linked mobile number" class="form-control"><br>
									<button type="submit" id="fetch" class="btn btn-info">Find Account</button>
									<hr>
									<div id="new_content">
										
									</div>
								</div>
							</div>
						</div>
					</div>

				
			</div>
		</div>
		
		<script type="text/javascript">
			$(document).ready(function() {
				//hiding signup form 
				//$("#global_error").hide();
				//$("#global_error2").hide();
				//$("#contentSignin").hide();

				//displaying signup form
				$("#signup1,#signup2,#signup3").on("click",function(e) {
					e.preventDefault();
					
					$("#contentUpdate").hide();
					$("#contentSignin").show(500);
				});

				//displaying login form
				$("#signin1,#signin2").on("click",function(e) {
					e.preventDefault();
					
					$("#contentUpdate").show(500);
					$("#contentSignin").hide();
				});
				//registering user

				$("#register").on("click",function() {
					var fname=$("#fname").val();
					var lname=$("#lname").val();
					var user_mobile=$("#mobile").val();
					var user_password=$("#password").val();
					var confirm_password=$("#cpassword").val();
					if (fname=="" || fname==null) {
						$("#fname_error").html("Please enter first name")
					}
					else if (lname=="" || lname==null) {
						$("#lname_error").html("Please enter last name")
					}
					else if (fname.length>20 || lname.length>20) {
						$("#lname_error").html("First name or Last name cannot exceed 20 characters")
					}
					else if (user_mobile=="" ||user_mobile==null) {
						$("#mobile_error2").html("Please enter mobile number")
					}
					else if (user_mobile.length!=10) {
						$("#mobile_error2").html("Please enter a valid mobile number")
					}
					else if ( isNaN(user_mobile.length)) {
						$("#mobile_error2").html("Please enter a valid mobile number")
					}
					else if ( user_password=="" || password==null) {
						$("#password_error2").html("Please enter the password")
					}
					else if ( user_password.length<6 || user_password.length>20) {
						$("#password_error2").html("Password must be in 6  to 20 characters")
					}
					else if (confirm_password!=user_password) {
						$("#cpassword_error").html("Confirm Password do not match")
					}
					else{
						$.ajax({
							url:"php/register.php",
							type:"POST",
							data:{ufname:fname, ulname:lname, user_mobile:user_mobile, user_password:confirm_password},
							success:function(data) {
								if (data==1) {
									location.href="index.php";
								}
								else{
									$("#global_error2").show();
									$("#global_error2").html(data);
								}
							}
						});
					}




				});

				//performing login
				$("#login").on("click",function(){
					var mobile=$("#user_mobile").val();
					var password=$("#user_password").val();
					if (mobile=="" || mobile==null) {
						$("#mobile_error").html("Mobile number cannot be empty")
					}
					else if (mobile.length!=10) {
						$("#mobile_error").html("Invalid mobile number")
					}
					else if (password=="" || password==null) {
						$("#password_error").html("Password cannot be empty")
					}
					else{
						$.ajax({
							url:"php/register.php",
							type:"POST",
							data:{mobile:mobile,password:password},
							success:function(data) {
								if (data==1) {
									location.href="index.php";
								}
								else{
									$("#global_error").show();
									$("#global_error").html(data);
								}
							}
						});
					}
				});

				//forget password
				$("#forget_password").click(function(e) {
					e.preventDefault();
					$("#forget_modal").modal("show");
				});

				$("#fetch").on("change",function() {
					$("#new_content").html("Please wait..");
				});

				$("#fetch").click(function(argument) {
					var mobile=$("#mobile_forget").val();
					if (mobile=="" || mobile==null) {
						$("#forget_error").show();
						$("#forget_error").html("Please enter your mobile ...");
					}
					else if(isNaN(mobile)){
						$("#forget_error").fadeIn();
						$("#forget_error").html("Please enter valid format of mobile number ...");
					}
					else if (mobile.length!=10) {
						$("#forget_error").show();
						$("#forget_error").html("Please enter valid format of mobile number ...");
					}
					else{
						$.ajax({
							url:"php/find_mobile.php",
							type:"POST",
							data:{mobile:mobile},
							success:function(data) {
								$("#new_content").html(data);
							}
						});
					}

				});


			});
				
				function verify() {
					$(".verify").show();
				}

				function change_password() {
							var password=$("#new_password").val();
					var mobile=$("#mobile_forget").val();

					var confirm_password=$("#confirm_password").val();

					if (password.length<8) {
						$("#p_error").show();
						$("#p_error").fadeIn();
						$("#p_error").html('Invalid Password length');
					}
					else if (password=="" || password==null){
						$("#p_error").show();
						$("#p_error").fadeIn();
						$("#p_error").html('Invalid Password');
					}
					else if (password!=confirm_password) {
						$("#p_error").show();
						$("#p_error").fadeIn();
						$("#p_error").html('Confirm password do not match');
					}
					else{

						$.ajax({
							url:"php/forget_password.php",
							type:"POST",
							data:{confirm_password:confirm_password,mobile:mobile},
							success:function(data) {
								$("#body").hide();
								$("#body").show();
								$("#body").fadeIn();
								$("#body").html(data);
							}
						});
					}
				}

				function close1() {
					$("#forget_modal").modal('hide');
				}
			
				

		</script>
	

</body>
</html>
					
					
		