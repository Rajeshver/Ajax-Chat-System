<?php 
include("config/connection.php");
if (!isset($_SESSION['mobile'])) {
	header('location:login.php');
	$_SESSION['error']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="style/styleindex.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
	
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  

  <style type="text/css">
  	small{
  		color: red;
  	}
  	.chat_buttons{
	width: 100%;
}
  	.chat_buttons button{
	width: 100%;
}
.navigation button{
	border: none;
	background-color: transparent;
	padding: 10px 20px;
	color: white;
	font-size: 22px;
}
.menu-bar button:hover{
	border-bottom: 1px solid white;
	transition: 0.5s ease;
}
.menu-bar{
	height: 600px;
	overflow: auto;
}
hr{
	background-color: white;
}
.contacts,.chat_area{
	height: 600px;
	overflow: auto;

	
}
#chat_arena button{
	background-color: transparent;
      color: white;
      border:none;
}
  i{
      color: white;

    }
    .chat_area1{
    	overflow: auto;
    }
    .contacts{
    	height: 600px;
    	overflow: auto;
    }
</style>

</head>
<body>
	<div class="userinfo container-fluid">
		<div class="row ">
			<div class="col-sm-3 navuser p-3 text-light">
				
					<div id="userdata">
						
					</div>
	<?php
		$select=mysqli_query($db,"SELECT * FROM users where mobile=".$_SESSION['mobile']."") or die("Select query failed");
		if ($select) {
	 		if (mysqli_num_rows($select)>0) {
	 		$user_data=mysqli_fetch_array($select);
	 		$_SESSION['sender_id']=$user_data['user_id'];
	 		
	 		?>			<input type="hidden" name="" id="session_id" value=<?php echo $_SESSION['sender_id']; ?>>
	 					<input type="hidden" name="" id="user_mobile_no" value=<?php echo $_SESSION['mobile']; ?>>

					</div>
	 		<?php
	 	}
	 } 
	?>
				
		
			<div class="col-sm-9">
				<div class="row ">
					<div class="col-sm-3 p-3 text-light navigation">
						<button title="Edit Profile" id="edit_profile" type="button" ><i class="fas fa-user"></i> Edit Profile</button>
					</div>
					<div class="col-sm-3 p-3 text-light navigation">
						<button title="Add Contact" type="button" data-toggle="modal" data-target="#add_contact_modal"><i class="fas fa-user-plus"></i> Add Contact</button>
					</div>
					<div class="col-sm-3 p-3 text-light navigation">
						<button title="Notifications" type="button" onclick="notifications()"><i class="fas fa-info"></i> Notifications</button><span class="badge badge-primary" id="n_count"></span>
					</div>
					<div class="col-sm-3 p-3 text-light navigation">
						<button title="Log Out"><i class="fas fa-power-off"></i><a href="logout.php"> Log Out</a></button>
					</div>
				</div>
			</div>
		</div>
		
	</div>
	<!-- Add contact modal -->
	<div class="modal fade" id="add_contact_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Contact</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="form-group">
        	<label>Enter Mobile Number</label><br>
        	
        	<input type="text" name="" id="add_mobile_number" class="form-control" placeholder="Enter Mobile Number">
        	<small id="add_user_error"></small><br>
        	<button type="button" class="btn btn-primary" id="add_button">Add Contact</button><br>
        	<div id="data_searched">
        		Searched Data Will be shown here.
        	</div>
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<!-- Notification Modal -->
	<div class="modal fade" id="notification_modal">
  		<div class="modal-dialog">
    		<div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Notifications</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	<div id="notifications">
      		
      	</div>
        
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<!-- Send Image Modal starts here  -->

<div class="modal fade" id="send_image_modal">
  		<div class="modal-dialog">
    		<div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Send Image File</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	<form id="upload_form">
			<label>Select Image to Send</label><br>
			<input type="file" name="image_file" id="image_file" class="form-control" onchange="loadfile(event)"><br>
			<img  id="imagetoload" width="200"><br><br>
			<input type="hidden" name="rec" id="rec"><br>
			<input type="hidden" name="sender_id" id="sender_id" value=<?php echo $_SESSION['sender_id']; ?>>
			<input type="submit" name="submit" value="Upload Image" id="submit" class="btn btn-primary">
		</form>
      	
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<!-- Send Image Modal ends here  -->

<!-- Send Image Modal starts here  -->

<div class="modal fade" id="set_profile_picture">
  		<div class="modal-dialog">
    		<div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Profile Picture</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	
	<form id="change_dp_form">
	<input type="hidden" name="user_ID1" id="user_ID1">
	<input type="file" class="form-control" id="dp_file" onchange="loadDP(event)" name="dp_file"><br>
	<img width="100" id="DP_preview"><br>
	<input type="submit" id="update_dp" class="btn btn-info" name="update_dp" value="Change Profile Picture">
	</form>
		
      	
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<!-- Send Image Modal ends here  -->

<!-- Notification Modal End -->

<!-- Contact Request Modal -->
<div class="modal fade" id="contact_requests_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" class="text-primary">Contact Requests</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <div id="requester_info">
       	
       </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<!-- Contact Request Modal End Here-->


<!-- Edit Profile Modal -->
<div class="modal fade" id="edit_profile_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" class="text-primary">Edit Profile</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <div id="info_user">
       	
       </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<!-- Edit Mobile Modal -->

<div class="modal fade" id="edit_mobile_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header bg-primary text-white">
        <h4 class="modal-title">Edit Mobile Number</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	<label>Enter Current Mobile Number:</label><br>
       <input type="text" name=""  id="current_mobile" placeholder="Enter Current Mobile Number.." class="form-control"><br>
       <label>Enter New Mobile Number:</label><br>
       <input type="text" name=""  id="new_mobile" placeholder="Enter New Mobile Number.." class="form-control"><br><br>
      
       <button id="change_mb" onclick="change_mb(<?php echo $user_data['user_id']; ?>)" class="btn btn-primary">Save Changes</button>
        <small id="mb_error" style="color: :red"></small>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<!-- Mobile modal ends here -->
	<div class="container-fluid">
		<div class="row ">
			<div class="col-sm-3  border setting menu-bar" style="background-color:#2d2d2d;">
				<h3 class=" p-3 border border-right-0 border-left-0 border-top-0 text-light">Menu</h3>
				<button type="button"  id="Chats" class="btn text-light" style="font-size: 1rem"><i class="fas fa-paper-plane"></i> Chats</button><br><hr>

				<button type="button" onclick="contacts(<?php echo $user_data['user_id']; ?>)" id="Contacts" class="btn text-light" style="font-size: 1rem"><i class="fas fa-user"></i> Contacts</button><br><hr>

				<button type="button" onclick="contact_requests_show(<?php echo $user_data['user_id'] ; ?>)" id="contact_requests2" class="btn text-light" style="font-size: 1rem"><i class="fas fa-user-plus"></i> Contact Requests</button><span class="badge badge-primary" id="total_requests"></span><br><hr>

				<button type="button" id="Edit_mobile" data-toggle="modal" data-target="#edit_mobile_modal" class="btn text-light" style="font-size: 1rem">
					<i class="fas fa-mobile"></i> Edit Mobile
				</button><br><hr>

				
				<button type="button" id="change_dp_button" class="btn text-light" style="font-size: 1rem"><i class="fas fa-image"></i> Change Profile Picure</button><br><hr>

				<button type="button" id="Blocked_Users" class="btn text-light" style="font-size: 1rem" onclick="blocked_users()"><i class="fas fa-ban"></i> Blocked Users</button><br><hr>

				<button type="button" id="change_password" class="btn text-light" style="font-size: 1rem" onclick="change_dialog()"><i class="fas fa-lock"></i> Change Password</button><br><hr>

				<button type="button" id="logout" class="btn text-light" style="font-size: 1rem"><i class="fas fa-power-off"></i> <a href="logout.php" class="text-light">Log Out</a></button><br><hr>
			</div>

			<div class="col-sm-3  border contacts" id="content_updation_area">
				<h3 class="text-info p-2 mb-0" id="chats_contact"><i class="fas fa-paper-plane"></i>Chats</h3>
				<input type="text" name="search_chat" class="form-control" id="search_contact" placeholder="Search Contacts">
				<span class="badge badge-info" id="unread_messages"></span>
				<hr>
				<div id="content_update1">
					
				</div>
			</div>
			<div class="col-sm-6  border chat_area bg-light" id="chat_arena">
				<div class="contact-info1 text-secondary">
					<div class="display-3 text-center mt-5 p-3 border ">
						Click on any user icon to start conversation
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Contacts requests show in this modal -->
	<div class="modal fade" id="contact_requests_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" class="text-primary">Contact Requests</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <div id="requests_data">
       
       </div>
      </div >

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button"  class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<!-- Update Password modal  -->
<div class="modal fade" id="change_password_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header badge-info text-white p-3">
        <h4 class="modal-title" class="text-primary">Change Password</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	<p class="alert alert-success" style="display: none" id="success_password"></p>
      	<div id="update_content_password">
      <label>Enter Current Password</label><br>
      <input type="password" id="current_password" placeholder="Enter Current Password" class="form-control" onkeyup="verify_password()"><br>
      <small style="display: none;padding: 10px" id="c_error1" class="alert alert-warning"></small>
      <div class="new_password_div" style="display: none">
      	<br>
      	<label>New Password</label><br>
      	<input type="password" name="" id="new_password1" placeholder="Enter new password" class="form-control"><br>

      	<label>Confirm Password</label><br>
      	<input type="password" name="" id="confirm_password1" placeholder="Re-type Password" class="form-control"><br>
      	<button onclick="update_password1()" class="btn btn-primary">Update Password</button>
      </div>
      </div >
  </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button"  class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
	
			
	
	<script type="text/javascript">
		
			

			
			loaded1();
			function loaded1() {
				load_info();
				number_of_requests();
				notifications_count();
				load_chat();
				unread_messages();				
				
				
			}
			
				
			

			function number_of_requests() {
				var session_id_of_user=$("#session_id").val();
				
				$.ajax({
					url:"php/total_requests.php",
					type:"POST",
					data:{session_id_of_user:session_id_of_user},
					success:function(data) {
						$("#total_requests").html(data);
					}

				});
			}

			function contact_requests_show(session_id) {
				var user_session_id=session_id;

				$.ajax({
					url:"php/show_request.php",
					type:"POST",
					data:{user_session_id:user_session_id},
					success: function(data) {
						
						$("#contact_requests_modal").modal("show");
						$("#requester_info").html(data);
						notifications_count();
						number_of_requests();

					}
				});
			}


			function load_info() {
				var mobile_of_user=$("#user_mobile_no").val();

				$.ajax({
					url:"php/load_info.php",
					type:"POST",
					data:{mobile_of_user:mobile_of_user},
					success:function(data) {
						$("#userdata").html(data);
						notifications_count();
						number_of_requests();
					}
				});
			}



			


			
			$("#edit_profile").on("click",function() {
				var user_mobile=$("#user_mobile_no").val();
				
				$.ajax({
					url:"php/user_database.php",
					type:"POST",
					data:{user_mobile:user_mobile},
					success:function(data) {
						$("#edit_profile_modal").modal("show");
						$("#info_user").html(data);
						load_info();
						number_of_requests();
						notifications_count();

					}
				});
			});



				function update() {
				 var u_fname=$("#update_firstname").val();
				 var u_lname=$("#update_lastname").val();
				 var user_mobile_no=$("#user_mobile_no").val();


				 	if (u_fname=="" || u_fname==null) {
						$("#u_fname_error").html("Please enter first name")
					}
					else if (u_lname=="" || u_lname==null) {
						$("#u_lname_error").html("Please enter last name")
					}
					else if (u_fname.length>20 || u_lname.length>20) {
						$("#lname_error").html("First name or Last name cannot exceed 20 characters")
					}
					
					else{
						$.ajax({
				 			url:"php/user_update.php",
				 			type:"POST",
				 			data:{u_fname:u_fname, u_lname:u_lname, user_mobile_no:user_mobile_no},
				 			success:function(data) {
				 			if (data==1) {
				 				$("#success2").html("Updation Successful");
				 				$("#edit_profile_modal").modal('hide');
				 				load_info();
				 				notifications_count();
				 				number_of_requests();
				 			
				 			}
				 			else{
				 				$("#error2").html("Updation Failed")
				 		
				 		}
				 	}
				 });

				}
			}



    
 	
				
					
				
				$("#add_button").on("click", function search() {
				var add_contact_number=$("#add_mobile_number").val();
				var session_number=$("#user_mobile_no").val();
				var session_user_id1=$("#session_id").val();
				if (add_contact_number=="" || add_contact_number==null) {
					$("#add_user_error").html("Please enter the mobile number");
				}
				else if (add_contact_number==session_number) {
					$("#add_user_error").html("You cannot enter your own number");
				}
				else{
					$.ajax({
						url:"php/search_add_contact.php",
						type:"POST",
						data:{add_contact_number:add_contact_number,session_user_id1:session_user_id1},
						success:function(data) {
							$("#data_searched").html(data);
							notifications_count();
							number_of_requests();
							
						}
					});
				}
			});
			
			
			

			function send_request() {
				var sent_user_id=$("#sent_user_id").val();
				var sender_id=$("#session_id").val();

				$.ajax({
					url:"php/send_request.php",
					type:"POST",
					data:{sent_user_id:sent_user_id,sender_id:sender_id},
					success:function(data) {
						$("#request_status").html(data);
						$("#send_contact_request").hide();
						$("#del_request_button").show();
						search_contact_add();
						load_info();
						number_of_requests();
						search();
						notifications_count();
					}
				});
			
			}
			
			function del_request(user_id,sender_id) {
				var user_del_id=user_id;
				var sender=sender_id;
				$.ajax({
					url:"php/send_request.php",
					type:"POST",
					data:{user_del_id:user_del_id,sender:sender},
					success:function(data) {
						if (data==1){
							alert("Request Deleted");
							$("#add_contact_modal").modal("hide");
							location.href="index.php";
							load_info();
							number_of_requests();
							notifications_count();

						}
						else{
							$("#request_status").html("Failed");
						}
					}
				});
			}
			function contacts(session1) {
				var session1=session1;
				$.ajax({
					url:"php/contacts.php",
					type:"POST",
					data:{session1:session1},
					success:function(data) {
						//alert(data);
						$("#content_update1").html(data);
						$("#chats_contact").html("Contacts");
						load_info();
						number_of_requests();
						notifications_count();
					}
				});
			}


function confirm_request(user_sender) {
	var user_sender=user_sender;
	var user_logged=$("#session_id").val();
	

	$.ajax({
		url:"php/confirm_request.php",
		type:"POST",
		data:{user_sender:user_sender,user_logged:user_logged},
		success:function(data) {
			alert(data);
			number_of_requests();
			contact_requests_show(user_logged);
			notifications_count();
			
		}
	});
	
}
function notifications_count() {
	var user=$("#session_id").val();
	$.ajax({
		url:"php/notifications.php",
		type:"POST",
		data:{user:user},
		success:function(data) {
			$("#n_count").html(data);
		}
	});

}
function notifications(){
	var user_here=$("#session_id").val();
	$.ajax({
		url:"php/notifications2.php",
		type:"POST",
		data:{userhere:user_here},
		success:function(data) {
			$("#notification_modal").modal("show");
			$("#notifications").html(data);
			notifications_count();
			
		}
	});
}


//Load Chat
function load_chat() {
	var id=$("#session_id").val();
	$.ajax({
		url:"php/load_chat.php",
		type:"POST",
		data:{id:id},
		success:function(data) {
			$("#content_update1").html(data);
			$("#chats_contact").html("Chats");
		}
	});
}

// Edit Mobile Number

function change_mb(user) {
 	var user=user;
 	var current_mobile=$("#user_mobile_no").val();
 	var current_mobile2=$("#current_mobile").val();
 	var new_mobile=$("#new_mobile").val();


 	if (current_mobile=="" || current_mobile==null) {
 		$("#mb_error").html("Please enter a valid mobile number");
 	}
 	else if (new_mobile=="" || new_mobile==null) {
 		$("#mb_error").html("Please enter a valid mobile number");
 	}

 	else if (current_mobile==new_mobile) {
 		$("#mb_error").html("You are already registered with this mobile number");
 	}
 	else if (new_mobile.length!=10) {
 		$("#mb_error").html("Please enter a valid mobile number");
 	}
 	else if (isNaN(new_mobile)) {
 		$("#mb_error").html("Please enter a valid mobile number");
 	}
 	else if (current_mobile!=current_mobile2) {
 		$("#mb_error").html("Invalid current mobile number");
 	}
 	else{
 		$.ajax({
		url:"php/edit_mobile.php",
		type:"POST",
		data:{user:user,new_mobile:new_mobile},
		success:function(data) {
			if (data==0) {
				alert('Invalid mobile number...\n Account already exists or something went wrong');
			}
			else{
				alert('Mobile number updated succesfully')
				location.href="index.php";
				loaded1();
			}
			
			
			
		}
	});
 	
 	}

 	
}

function load_chat_contact(sender,receiver) {
	var sender=sender;
	var receiver=receiver;

	$.ajax({
		url:"php/load_chat_contact.php",
		type:"POST",
		data:{sender:sender, receiver:receiver},
		success:function(data) {
			$("#chat_arena").html(data);
			load_messages();
			unread_messages();

			
		}
	});
}



function load_messages() {
	var sender_id=$("#session_id").val();
	var receiver_id=$("#receiver_id1").val();
	
	
	$.ajax({
		url:"php/load_messages.php",
		type:"POST",
		data:{sender_id:sender_id, receiver_id:receiver_id},
		success:function(data){

			$("#chat_area1").html(data);
			unread_messages();
			//load_chat();

		}
	});
	
}
function send_message() {
	var sender_user=$("#session_id").val();
	var receiver_id=$("#receiver_id1").val();
	var message=$("#message_to_sent").val();
	//alert(sender_user+' '+receiver_id+' '+message)

	$.ajax({
		url:"php/send_message.php",
		type:"POST",
		data:{sender_user:sender_user, receiver_id:receiver_id, message:message},
		success:function() {
			
			$("#send_message_form").trigger("reset");
			load_messages();
			load_chat();
			
		}
	});
}

$("#Chats").on("click",function() {
	load_chat();
});

function delele_msg() {
	var	msg_id=$("#msg_id").val();
	if (confirm("Are your sure to delete this message")==false) {
		load_messages();
		load_chat();
	}
	else{
		$.ajax({
		url:"php/delete_msg.php",
		type:"POST",
		data:{msg_id:msg_id},
		success:function(data) {
			alert(data);
			load_messages();
			
		}
	});
	}
	
}


function unread_messages() {
	var user=$("#session_id").val();

	$.ajax({
		url:"php/unread_messages.php",
		type:"POST",
		data:{user:user},
		success:function(data) {
			$("#unread_messages").html(data);
			load_messages();

			
		}
	});
}


function del_chat(){
	var sender_user=$("#session_id").val();
	var receiver_id=$("#receiver_id1").val();

	if(confirm("Are you sure to delete the whole chat")==false){
		loaded1();
	}
	else{

		$.ajax({
			url:"php/delete_chat.php",
			type:"POST",
			data:{sender_user:sender_user, receiver_id:receiver_id},
			success:function (data) {
				alert(data);
				load_chat();
				load_messages();
				
			}
		});
	}
}

//block contact

function block_contact(){
	var sender_id=$("#session_id").val();
	var receiver_id=$("#receiver_id1").val();
	if (confirm("Are you sure to block this contact?")==false) {
		load_chat();
		load_messages();
	}

	$.ajax({
		url:"php/block_contact.php",
		type:"POST",
		data:{sender_id:sender_id, receiver_id:receiver_id},
		success:function(data) {
			alert(data);
			load_chat();
			$("#chat_arena").load('textarea.php');
			
			
		}
	});

}



//open image send dialog box
function send_image_modal() {
	var receiver_id=$("#receiver_id1").val();
	$("#send_image_modal").modal("show");
	$("#rec").val(receiver_id);
	


}


//file preview
function loadfile(event) {
      var reader= new FileReader();
      reader.onload=function() {
        var output=document.getElementById('imagetoload');
        output.src=reader.result;
      }
      reader.readAsDataURL(event.target.files[0]);
    }

//sending image file

    $("#upload_form").on("submit",function(e) {
				e.preventDefault();


				var sender_id=$("#session_id").val();
				var receiver_id=$("#receiver_id1").val();
				var formdata= new FormData(this);

				$.ajax({
					url:"upload.php",
					type:"POST",
					data:formdata,sender_id,receiver_id,
					contentType:false,
					processData:false,
					success:function(data) {
						alert(data);
						$("#send_image_modal").modal("hide");

					}
				});
			});

    function blocked_users() {
    	var sender_id=$("#session_id").val();

    	$.ajax({
    		url:"php/blocked_users.php",
    		type:"POST",
    		data:{sender_id:sender_id},
    		success:function(data) {
    			$("#content_update1").html(data);
				$("#chats_contact").html("Blocked Contacts");
    		}
    	});
   
}

    function unblock_user(){
    	var sender_id=$("#session_id").val();
    	var blocked_id=$("#blocked_id").val();

    	if (confirm("Are you sure to unblock this user?")==false) {
    		load_chat();
    	}
    	else{
    		$.ajax({
    		url:"php/unblock.php",
    		type:"POST",
    		data:{sender_id:sender_id,blocked_id:blocked_id},
    		success:function(data) {
    			alert(data)
    			blocked_users();
    		}
    	});
    	}
    	
    }
    $("#change_dp_button").on("click",function() {
				$("#set_profile_picture").modal("show");
				var sender_id=$("#session_id").val();
				$("#user_ID1").val(sender_id);
				
			});


		function loadDP(event){
    	var reader= new FileReader();
      reader.onload=function() {
        var output=document.getElementById('DP_preview');
        output.src=reader.result;
      }
      reader.readAsDataURL(event.target.files[0]);
    }

    


     $("#change_dp_form").on("submit",function(e) {
				e.preventDefault();
				

				
				var formdata= new FormData(this);
				
				$.ajax({
					url:"change_dp.php",
					type:"POST",
					data:formdata,sender_id,
					contentType:false,
					processData:false,
					success:function(data) {
						alert(data);
						$("#set_profile_picture").modal("hide");
						load_info();
						unread_messages();
						

					}
				});
			});


     //live search contact list

     $("#search_contact").on("keyup", function() {
     	
     	var search_key=$("#search_contact").val();
     	var user=$("#sender_id").val();

     	$.ajax({
     		url:"php/contact_search.php",
     		type:"POST",
     		data:{search_key:search_key, user:user},
     		success:function(data) {
     			$("#content_update1").html(data);
     		}
     	});
     });
     load_chat();

     //change dialog box

     
     function change_dialog() {
     	$("#change_password_modal").modal('show');
     }



     //verify password

     function verify_password(){
     	var user=$("#session_id").val();
     	var current_password=$("#current_password").val();
     	var c_error=$("#c_error1");
     	if (current_password=="" || current_password==null) {
     		c_error.show();
     		c_error.html('Please enter your password');
     	}
     	else if (current_password.length<6) {
     		c_error.show();
     		c_error.html('Invalid current password');
     	}
     	else{
     		c_error.html('Please wait..');
     		$.ajax({
     			url:"php/verify_password.php",
     			type:"POST",
     			data:{user:user,current_password:current_password},
     			success:function(data) {
     				if (data==1) {
     					c_error.html('Password Verified succesfully...');
     					$(".new_password_div").show();
     				}
     				else{
     					c_error.html('Password do not match...');
     				}
     				
     			}
     		});
     	}
     }

     function update_password1(){

     	var user=$("#session_id").val();
     	var new_password=$("#new_password1").val();
     	var confirm_password=$("#confirm_password1").val();
     	var c_error=$("#c_error1");

     	if (new_password=="" || new_password==null) {
     		c_error.html('Please enter new password...');
     	}
     	else if (new_password.length<6) {
     		c_error.html('Password must include atleast 6 charcters...');
     	}
     	else if (new_password!=confirm_password) {
     		c_error.html('Confirm password do not match');
     	}
     	else{
     		$.ajax({
     			url:"php/update_password.php",
     			type:"POST",
     			data:{user:user,confirm_password:confirm_password},
     			success:function(data) {
     				$("#success_password").show();
     				$("#success_password").html("Password updated Successfully");
     				$(".new_password_div").hide();
     			}
     		});
     	}
     	}
     		
     

   
		

	</script>






	
	
	

</body>
</html>