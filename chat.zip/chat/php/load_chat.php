<?php
include('../config/connection.php');

if (isset($_POST['id'])) {
	
	$id=$_POST['id'];
	$chats_contacts_sender="";
	$chats_contacts_receiver="";
	$users_array=array();

	$select=mysqli_query($db,"SELECT * FROM messages where sender_id='$id' or receiver_id='$id' ") or die('Contact query failed');
	if ($select) {
		while ($rows=mysqli_fetch_assoc($select)) {
			if ($rows['sender_id']==$id) {
				$receiver_id= $rows['receiver_id']."<br>";
				$sender_user=mysqli_query($db,"SELECT * FROM users where user_id='$receiver_id '") or die('Failed');
				$users=mysqli_fetch_array($sender_user);
				
				array_push($users_array, $users['user_id']);
			}
			else{
				$sender_id= $rows['sender_id']."<br>";
				$sender_user1=mysqli_query($db,"SELECT * FROM users where user_id='$sender_id' ") or die('Failed');
				$users=mysqli_fetch_array($sender_user1);
				array_push($users_array, $users['user_id']);
			}
			
		}
		$unique_users=array_unique($users_array);
		$uniques=implode(",", $unique_users);
		$select_uniques=mysqli_query($db,"SELECT * FROM users where user_id IN($uniques)") or die('No chat yet...');
		if ($select) {
			if (mysqli_num_rows($select_uniques)) {
				while($u_users=mysqli_fetch_assoc($select_uniques)){
					$fname=$u_users['fname'];
					$lname=$u_users['lname'];
					$mobile=$u_users['mobile'];
					$dp=$u_users['dp'];
					$user_id=$u_users['user_id'];

					//selecting msg

					$select_msg=mysqli_query($db,"SELECT * FROM messages where (sender_id='$id' AND receiver_id='$user_id') OR (sender_id='$user_id' AND receiver_id='$id') ORDER BY msg_id DESC");
					$last=mysqli_fetch_assoc($select_msg);
					if ($last['status']=="sent" and $last['receiver_id']==$id) {
						$unread='<h4 class="ml-2">'.$last['message'].'</h4>';
						

						$select_number_sent=mysqli_query($db,"SELECT * FROM messages where status='sent' and receiver_id='$id' and sender_id='$user_id'");
						$rows=mysqli_num_rows($select_number_sent);
						$display='
						<div class="media" onclick="load_chat_contact('.$id.','.$user_id.')">
										<input type="hidden" value='.$user_id.' id="this">
										<img src="'.$dp.'" width="18%" height="18%" class="">
										<div class="media-body">
											<h5 class="m-1">'.$fname.' '.$lname.'</h5>
											'.$unread.'<span class="badge badge-primary">'.$rows.'<span>
										</div>
									</div><hr>';

									echo $display;


					

					}
					else{
						$common='<p class="ml-2">'.$last['message'].'</p>';
						$display='
						<div class="media" onclick="load_chat_contact('.$id.','.$user_id.')">
										<input type="hidden" value='.$user_id.' id="this">
										<img src="'.$dp.'" width="60" height="60" class="">
										<div class="media-body">
											<h5 class="m-1">'.$fname.' '.$lname.'</h5>
											'.$common.'
										</div>
									</div><hr>';


					echo $display;
					}

					
				}
			}
		}
	}
}
?>
