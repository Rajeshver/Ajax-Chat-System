<?php
include('../config/connection.php');


if (isset($_POST['user_session_id'])) {
	$user_session_id=$_POST['user_session_id'];

	$select=mysqli_query($db,"SELECT * FROM contact_requests where user_sent_id='$user_session_id'");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			while($data=mysqli_fetch_assoc($select)){
				$select_sender=mysqli_query($db,"SELECT * FROM users where user_id=".$data['sender_id']."") or die("Failed");
				if ($select) {
					if (mysqli_num_rows($select_sender)>0) {
						$sender_data=mysqli_fetch_assoc($select_sender);
						$show='<div class="media mt-3">
			<input type="hidden" value="'.$sender_data['user_id'].'" id="sent_user_id2">
			<img src="'.$sender_data['dp'].'" width="20%" class="shadow">
			<div class="media-body ml-2 ">
				<h4 class="m-0">'.$sender_data['fname'].' '.$sender_data['lname'].' </h4>
				<p class="m-0"> '.$sender_data['mobile'].'</p>
				<button id="confirm_request" class="btn btn-success" onclick="confirm_request('.$sender_data['user_id'].')">Confirm Request</button>
				<button id="del_request" class="btn btn-danger" onclick="del_request('.$user_session_id.','.$sender_data['user_id'].')">Delete Request</button>
			</div><br>
			<p id="request_true" class="bg-success text-light p-2"></p>
			</div> ';
			echo $show;
					}
					else{
						echo "User Not Founf....";
					}
				}
			}
		}
		else{
			echo "<h4>No Request Found....</h4>";
		}
	}
	else{
		echo "Query Failed(Find Requests)";
	}
}
?>