<?php
include('../config/connection.php');


if (isset($_POST['user'])) {
	$user=$_POST['user'];
	$select=mysqli_query($db,"SELECT * FROM messages where receiver_id='$user' AND status='sent'");
	if ($select) {
		if (mysqli_num_rows($select)==0) {
			echo "No unread messages";
		}
		else{
			$rows=mysqli_num_rows($select);
			echo $rows.' unread messages';
		}
	}
}


?>