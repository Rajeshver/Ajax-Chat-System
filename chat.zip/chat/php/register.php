<?php
include('../config/connection.php');

//registering user

	if (isset($_POST['ufname']) && isset($_POST['ulname']) && isset($_POST['user_mobile']) && isset($_POST['user_password'])) {
		
	
	
	$fname=$_POST['ufname'];
	$lname=$_POST['ulname'];
	$mobile=$_POST['user_mobile'];
	$password=$_POST['user_password'];
	$password2=md5($password);
	$dp="stock/planner.png";
	$error="";
	$success="";
	$select=mysqli_query($db,"SELECT * FROM users where mobile='$mobile'") or die("Query Failed");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			
			echo "Mobile number already registered";
		}
		
		else{
			$insert=mysqli_query($db,"INSERT INTO users (fname,lname,mobile,password,dp) VALUES ('$fname','$lname','$mobile','$password2','$dp')") or die("Insert query failed");
			if ($insert) {
				$success=1;
				$_SESSION['mobile']=$mobile;
				echo $success;
			}
			
		}
	}
}

if (isset($_POST['mobile']) && isset($_POST['password'])) {
	
	$mobile=$_POST['mobile'];
	$password=$_POST['password'];
	$password2=md5($password);

	$select=mysqli_query($db,"SELECT * FROM users where mobile='$mobile' AND password='$password2'") or die("Cannot log in");
	if ($select) {
		if (mysqli_num_rows($select)==1) {
			$_SESSION['mobile']=$mobile;
			echo 1;
		}
		else{
			echo "Wrong mobile number or password";
		}
	}
}



?>