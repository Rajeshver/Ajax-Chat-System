<?php 
include('../config/connection.php');
if (isset($_POST['add_contact_number']) && isset($_POST['session_user_id1'])){
	
	$add_contact_number=$_POST['add_contact_number'];
	$session_id=$_POST['session_user_id1'];
	$user_sent="";
	//check if the user exists

	$select=mysqli_query($db,"SELECT * FROM users where mobile='$add_contact_number'") or die('Select if user exist query failed');
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			$userdata=mysqli_fetch_assoc($select);
			//checking if user is blocked or not
			$user_sent=$userdata['user_id'];
			$select_blocked=mysqli_query($db,"SELECT * FROM blocked_users where blocked_user=".$user_sent." AND blocked_by='$session_id' ") or die('Check user blocked or not query failed');
			if ($select_blocked) {
				if (mysqli_num_rows($select_blocked)>0) {
					echo '<p class="text-danger">This user has blocked you or you have blocked him.</p>';
				}
				else{

					//check if user is already a contact
					$select_contact=mysqli_query($db,"SELECT * FROM contacts where (user='$session_id' AND contact=".$userdata['user_id'].") OR ( user=".$userdata['user_id']." AND contact='$session_id' )");
					if ($select_contact) {
						if (mysqli_num_rows($select_contact)>0) {
							echo '<p class="text-green">You are already contact with this user</p>';
						}
						else{
							//checking if request has been sent

							$select_request=mysqli_query($db,"SELECT * from contact_requests where (sender_id='$session_id' AND user_sent_id='$user_sent') OR (sender_id='$user_sent' AND user_sent_id='$session_id')");
							if ($select_request) {
								if (mysqli_num_rows($select_request)>0) {
									echo '<p class="text-green">Contact Request already sent.</p>';
								}
								else{
									//selecting user
									$select_user=mysqli_query($db,"SELECT * FROM users where mobile='$add_contact_number'");
							if ($select_user) {
								if (mysqli_num_rows($select_user)>0) {
									$user_info1=mysqli_fetch_assoc($select_user);

									$display='<div class="media mt-3">
			<input type="hidden" value="'.$user_info1['user_id'].'" id="sent_user_id">
			<img src="'.$user_info1['dp'].'" width="20%" class="shadow">
			<div class="media-body ml-2 ">
				<h4 class="m-0">'.$user_info1['fname'].' '.$user_info1['lname'].' </h4>
				<p class="m-0"> '.$user_info1['mobile'].'</p>
				<button type="button" id="send_contact_request" class=" btn btn-primary" onclick="send_request()">Send Request</button>
				<button type="button" id="del_request_button" class=" btn btn-danger" onclick="del_request('.$user_info1['user_id'].','.$session_id.')" style="display:none">Delete Request</button><br>
				
			</div><br>
			<p id="request_status" class="bg-success text-light p-2"></p>
			</div> ';

									echo $display;
									

								}
								else{
									echo "<h3>User do not exist with this mobile number.. </h3>";
								}
							}
							else{
								echo "Select last user query failed";
							}
								}
							}
							else{

							}
						}
					}
					else{
						echo "Contact select query failed";
					}
				}
			}
			else{
				echo "Check user blocked or not query failed";
			}
		}
		else{
			echo "<h3>User do not exist with this mobile number.. </h3>";
		}
	}
	else{
		echo "Select if user exist query failed'";
	}



}
else{
	echo "Something gone wrong";
}
?>


							
 
			



















