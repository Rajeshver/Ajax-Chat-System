<?php
include('../config/connection.php');


if (isset($_POST['msg_id'])) {
	$msg_id=$_POST['msg_id'];

	$delete=mysqli_query($db,"DELETE from messages where msg_id='$msg_id'") or die("Failed");
	if ($delete) {
		echo "Message deleted successfully";
	}else{
		echo "Failed to delete this message";
	}
}

?>