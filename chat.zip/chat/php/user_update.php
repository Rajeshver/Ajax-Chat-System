<?php
include("../config/connection.php");
//if (isset($_POST['u_fname']) && isset($_POST['u_lname']) && isset($_POST['u_mobile']) && isset($_POST['u_password']) && isset($_POST['user_mobile_no'])) {
	
	$u_fname=$_POST['u_fname'];
	$u_lname=$_POST['u_lname'];
	
	$user_mobile_no=$_POST['user_mobile_no'];
	

	$update=mysqli_query($db,"UPDATE users SET fname='$u_fname', lname='$u_lname' where mobile='$user_mobile_no'") or die("Update query failed");


	if ($update) {
		echo 1;
		}
		
	
	else{
		echo 0;
	}


//}
?>