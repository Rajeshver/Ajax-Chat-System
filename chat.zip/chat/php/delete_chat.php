<?php

include('../config/connection.php');

if (isset($_POST['sender_user']) && isset($_POST['receiver_id'])) {
	$sender_user=$_POST['sender_user'];
	$receiver_id=$_POST['receiver_id'];


	$delete_chat=mysqli_query($db,"DELETE FROM messages where (sender_id='$sender_user' AND receiver_id='$receiver_id') OR (sender_id='$receiver_id' AND receiver_id='$sender_user')");
	if ($delete_chat) {
		echo "Chat deleted successfully";
	}
	else{
		echo "Failed to delete chat";
	}
}


?>
