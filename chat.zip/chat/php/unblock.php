<?php

include('../config/connection.php');

if (isset($_POST['sender_id']) && isset($_POST['blocked_id'])) {
	
	$session=$_POST['sender_id'];
	$blocked_id=$_POST['blocked_id'];

	//check if the user in blocklist exist
	$select=mysqli_query($db,"SELECT * FROM blocked_users where blocked_user='$blocked_id' AND blocked_by='$session'");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			
			$delete=mysqli_query($db,"DELETE from blocked_users where blocked_user='$blocked_id' AND blocked_by='$session'");
			if ($delete) {
				echo "User removed from block list successfully";
			}
			else{
				echo "Deletion Failed";
			}
		}
	}
	else{
		echo "User not found...";
	}
}

?>