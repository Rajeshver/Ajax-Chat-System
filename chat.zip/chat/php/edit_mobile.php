<?php
include('../config/connection.php');

if (isset($_POST['user']) && isset($_POST['new_mobile'])) {
	$user=$_POST['user'];
	$new_mobile=$_POST['new_mobile'];

	$select=mysqli_query($db,"SELECT * FROM users where mobile='$new_mobile'");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			echo 0;
		}
		else{
			$update=mysqli_query($db,"UPDATE users SET mobile='$new_mobile' where user_id='$user'");
			if ($update) {
				$_SESSION['mobile']=$new_mobile;
				echo 1;
			}
			else{
				echo 0;
			}
		}
	}
	else{
		echo 0;
	}
	
}

?>