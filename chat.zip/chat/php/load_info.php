<?php

include("../config/connection.php");

if (isset($_POST['mobile_of_user'])) {
 	$mobile_of_user=$_POST['mobile_of_user'];
 	$data="";

 	$select=mysqli_query($db,"SELECT * from users where mobile='$mobile_of_user'") OR die("User Information not fetched");
 	if ($select) {
 		if (mysqli_num_rows($select)>0) {
 			$user_info=mysqli_fetch_array($select);
 			$data='<div class="media " >
 			<img src="'.$user_info['dp'].'" width="50" height="50" class="shadow">
	 				<div class="media-body ml-2">
						<h4 class="m-0" id="user">'.$user_info['fname'].' '. $user_info['lname'].'</h4 class="m-0">
	 					<p class="m-0" id="user"> '.$user_info['mobile'].'</p>
	 					<input type="hidden" name="" id="user_mobile_no" value='.$user_info['mobile'].' ?>
					</div></div>';

 		}
 		echo $data;
 	}
 } 
?>