<?php 
include("../config/connection.php");

if (isset($_POST['user_mobile'])) {
	$user_mobile=$_POST['user_mobile'];
	$userdata2="";
	$select=mysqli_query($db,"SELECT * FROM users where mobile='$user_mobile'")or die("Select user query failed");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			
			while ($rows=mysqli_fetch_assoc($select)) {
				$userdata2='<p class="text-success" id="success2"></p><p class="text-danger" id="error2"></p>
				<div >
		<label>Profile Picture</label>
		<br>
		 <img src="'.$rows['dp'].'" width="60" height="60" class="shadow rounded-circle">
	</div>
	
	<hr>
	<div >
		<label>First Name</label>
		<input type="text" name="" class="form-control" id="update_firstname" value=  "'.$rows['fname'].'">
		<small id="u_fname_error"></small>
	</div><br>
	<div >
		<label>Last Name</label>
		<input type="text" name="" class="form-control" id="update_lastname" value="'.$rows['lname'].'">
		<small id="u_lname_error"></small>
	</div><br>
	
	
	<div >
	<hr>
		<button type="button" id="save_changes" onclick="update()" class="btn btn-primary">Save Changes</button>
	</div>';

			}


		}
		echo $userdata2;
	}
}





?>
