<?php 

include('../config/connection.php');

if (isset($_POST['sender_user']) && isset($_POST['receiver_id']) && isset($_POST['message'])) {

	$sender_id=$_POST['sender_user'];
	$receiver_id=$_POST['receiver_id'];
	$text_message=$_POST['message'];
	$status="sent";
	$message_type="text";

	$insert=mysqli_query($db,"INSERT INTO messages (sender_id,receiver_id,message_type,message,status) VALUES ('$sender_id','$receiver_id','$message_type','$text_message','$status')") or die('query failed');

	if ($insert) {
		//echo "Message Sent";
	}
	else{
		//echo "Failed";
	}
}
else{
	echo "Something going wrong";
}


?>