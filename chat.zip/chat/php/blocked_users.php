<?php

include('../config/connection.php');

if (isset($_POST['sender_id'])) {
	
	$sender_id=$_POST['sender_id'];

	$select_blocked=mysqli_query($db,"SELECT * FROM blocked_users where blocked_by='$sender_id'");
	if ($select_blocked) {
		if (mysqli_num_rows($select_blocked)>0) {
			while ($data=mysqli_fetch_assoc($select_blocked)) {
				$select_users=mysqli_query($db,"SELECT * FROM users where user_id=".$data['blocked_user']."");
				if ($select_users) {
					if (mysqli_num_rows($select_users)>0) {
						$user=mysqli_fetch_assoc($select_users);
						$display='<div class="media">
						<input type="hidden" value="'.$user['user_id'].'" id="blocked_id">
	<img src="'.$user['dp'].'" width="60" height="60" class="mr-2 " >
	<div class="media-body">
		<h4 class="mb-1">'.$user['fname'].' '.$user['lname'].'</h4>
		<label>'.$user['mobile'].'</label><br>
		<button class="btn btn-danger" onclick="unblock_user()">Un-Block User</button>
	</div>
</div>

<hr>'
;				
					echo $display;

					}
					else{
						echo "No blocked user found...";
					}
				}
				else{
					echo "Sorry..User Query not running";
				}
			}
		}
		else{
			echo "No blocked contacts found....";
		}
	}
	else{
		echo "Sorry..Query not running";
	}
}

?>
