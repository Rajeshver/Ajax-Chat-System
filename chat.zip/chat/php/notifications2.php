<?php

include('../config/connection.php');


if (isset($_POST['userhere'])) {
	$userhere=$_POST['userhere'];

	$select2=mysqli_query($db,"SELECT * FROM notifications where user_id='$userhere' ORDER BY Id DESC");
	if ($select2) {
		if (mysqli_num_rows($select2)>0) {
			while ($rows2=mysqli_fetch_assoc($select2)) {
				$display= '<div class="border p-2 text-success bg-light mt-1">'.$rows2['notification']. '</div><hr>';

				$update=mysqli_query($db,"UPDATE notifications SET status='Read' where user_id='$userhere'");
				if ($update) {
					echo $display;
				}
				else{
					echo "Update query failed";
				}
			}
		}
		else{
			echo "No New Notification";
		}
	}
}


?>