<?php 
include('../config/connection.php');

if (isset($_POST['session_id_of_user'])) {
	$session_id_of_user=$_POST['session_id_of_user'];

	$select=mysqli_query($db,"SELECT * FROM contact_requests where user_sent_id='$session_id_of_user'");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			$reqests=mysqli_num_rows($select);
			echo $reqests;
		}
		else{
			echo "0";
		}
	}
	else
	{
		echo "Query Failed";
	}
}



?>