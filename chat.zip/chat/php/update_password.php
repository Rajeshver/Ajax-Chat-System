<?php 
include("../config/connection.php");

if (isset($_POST['user']) && isset($_POST['confirm_password'])) {
	
	$user=$_POST['user'];
	$confirm_password=$_POST['confirm_password'];
	$confirm_password2=md5($confirm_password);

	if (!ctype_alnum($confirm_password)) {
		echo 0;
	}
	else{

		$update=mysqli_query($db,"UPDATE users SET password='$confirm_password2' where user_id='$user'");
		if ($update) {
			echo "Password Updated Successfully...";
		}
		else{
			echo 1;
		}
	}
}
else{
	echo "Something gone wrong";
}


?>