<?php

include('../config/connection.php');

if (isset($_POST['sent_user_id']) && isset($_POST['sender_id'])) {
	$sender_id=$_POST['sender_id'];
	$sent_user_id=$_POST['sent_user_id'];
	$status="Request Sent";
	
	
			$send=mysqli_query($db,"INSERT into contact_requests(sender_id,user_sent_id,status) VALUES ('$sender_id','$sent_user_id','$status')") or die("Request cannot be sent");
			if ($send) {
				echo "Request Sent Successfully";
			}
			else{
				echo "Request Sent Failed";
			}
		
		

	

}

if (isset($_POST['user_del_id'])) {
	$user_del_id=$_POST['user_del_id'];
	$sender=$_POST['sender'];

	$delete=mysqli_query($db,"DELETE FROM contact_requests where user_sent_id='$user_del_id' AND sender_id='$sender'");
	if ($delete) {
		echo 1;
	}
	else{
		echo 0;
	}
}



?>
