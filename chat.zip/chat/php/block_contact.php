<?php

include('../config/connection.php');

if (isset($_POST['sender_id']) && isset($_POST['receiver_id'])) {
	$sender_id=$_POST['sender_id'];
	$receiver_id=$_POST['receiver_id'];

	$block=mysqli_query($db,"INSERT INTO blocked_users (blocked_user,blocked_by) VALUES ('$receiver_id','$sender_id')");
	if ($block) {
		$delete=mysqli_query($db,"DELETE FROM contacts where (user='$sender_id' AND contact='$receiver_id') or (user='$receiver_id' AND contact='$sender_id')");
		if ($delete) {
			$delete_chat=mysqli_query($db,"DELETE FROM messages where (sender_id='$sender_id' AND receiver_id='$receiver_id') OR (sender_id='$receiver_id' AND receiver_id='$sender_id')");
			if ($delete) {
				echo "Contact Bloked Successfully";
			}
			else{
				echo "User Bloked but chat not deleted";
			}
		}
		else{
			echo "User Bloked but chat and contact not deleted";
		}
	}
	else{
		echo "Failed to block user";
	}
}





?>