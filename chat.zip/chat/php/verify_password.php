<?php 

include("../config/connection.php");

if (isset($_POST['current_password']) && isset($_POST['user'])) {
	$user=$_POST['user'];
	$current_password=$_POST['current_password'];
	$current_password2=md5($current_password);



	$select=mysqli_query($db,"SELECT * FROM users where user_id='$user' AND password='$current_password2'");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			echo 1;
		}
		else{
			echo 0;
		}
	}
	else{
		echo 0;
	}
}


?>