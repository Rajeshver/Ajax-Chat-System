<?php

include('../config/connection.php');

if (isset($_POST['user'])) {
	$user=$_POST['user'];

	$select=mysqli_query($db,"SELECT * FROM notifications where user_id='$user' and status='Unread'");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			$notes=mysqli_num_rows($select);
			echo $notes;
		}
	}
}



?>