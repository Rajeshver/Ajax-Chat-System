<?php

include('../config/connection.php');

if (isset($_POST['sender_id']) && isset($_POST['receiver_id'])) {


	$sender_id=$_POST['sender_id'];
	$receiver_id=$_POST['receiver_id'];

	$display="";
	$select_messages=mysqli_query($db,"SELECT * FROM messages where (sender_id='$sender_id' AND receiver_id='$receiver_id') OR (sender_id='$receiver_id' AND receiver_id='$sender_id')  ORDER BY msg_id DESC")or die('Messaged not loaded');
	if ($select_messages) {
		if (mysqli_num_rows($select_messages)>0) {
			while ($messages=mysqli_fetch_assoc($select_messages)) {

				$display='<div class=>';
				if ($messages['sender_id']==$sender_id && $messages['message_type']=='text') {
					$display.='<div class="d-flex justify-content-end mt-1" ondblclick="delele_msg()" style="cursor: pointer;">
					<p class="bg-primary p-2 text-white" >'.$messages['message'].'</p>
					<input type="hidden" value='.$messages['msg_id'].' id="msg_id">
					</div>';
				}

				elseif ($messages['sender_id']==$sender_id && $messages['message_type']=='image') {
					$display.='<div class="d-flex justify-content-end mt-1" ondblclick="delele_msg()" style="cursor: pointer;">
					<a href="'.$messages['message'].'"><img src="'.$messages['message'].'" width="100"></a>
					<input type="hidden" value='.$messages['msg_id'].' id="msg_id">
					</div>';
				}

				elseif ($messages['sender_id']==$receiver_id && $messages['message_type']=='image') {
					$display.='<div class="d-flex justify-content-start mt-1" ondblclick="delele_msg()" style="cursor: pointer;">
					<a href="'.$messages['message'].'"><img src="'.$messages['message'].'" width="100"></a>
					<input type="hidden" value='.$messages['msg_id'].' id="msg_id">
					</div>';
				}

				elseif ($messages['receiver_id']==$receiver_id && $messages['message_type']=='image') {
					$display.='<div class="d-flex justify-content-end mt-1" ondblclick="delele_msg()" style="cursor: pointer;">
					<a href="'.$messages['message'].'"><img src="'.$messages['message'].'" width="100"></a>
					<input type="hidden" value='.$messages['msg_id'].' id="msg_id">
					</div>';
				}

				else{
					$display.='<div class="d-flex justify-content-start mt-1" ondblclick="delele_msg()" style="cursor: pointer;">
					<p class="bg-success p-2 text-white" >'.$messages['message'].'</p>
					<input type="hidden" value='.$messages['msg_id'].' id="msg_id">
					</div>';
				}
				
				$display.='<input type="hidden" id="msg_id" value='.$messages['msg_id'].'>
				</div>';
				$status="Delivered";
				$update=mysqli_query($db,"UPDATE messages SET status='$status' where receiver_id='$sender_id' and sender_id='$receiver_id'");
				echo $display;
			}
		}

		else{
			echo 'No chat yet.....';
		}
	}

}
else{
	echo "Something went wrong";
}

?>


