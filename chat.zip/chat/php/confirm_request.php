<?php
include('../config/connection.php');

if (isset($_POST['user_sender'])) {
	$user_sender=$_POST['user_sender'];
	$user_logged=$_POST['user_logged'];

	$select=mysqli_query($db,"SELECT * FROM contacts where user='$user_logged' AND contact='$user_sender'");
	if ($select) {
		if (mysqli_num_rows($select)==0) {
			$insert=mysqli_query($db,"INSERT INTO contacts (user,contact) VALUES ('$user_logged','$user_sender')");
			if ($insert) {
				$delete=mysqli_query($db,"DELETE from contact_requests where sender_id='$user_sender' AND user_sent_id='$user_logged'");
				if ($delete) {
					$select_info=mysqli_query($db,"SELECT * FROM users where user_id='$user_logged'");
					if ($select_info) {
						if (mysqli_num_rows($select_info)>0) {
							$data_user=mysqli_fetch_array($select_info);
							$username=$data_user['fname']." ".$data_user['lname'];
							$message='<p>'.$username.' Accepted your contact request</p>';
							//inserting notification
							$notification=mysqli_query($db,"INSERT into notifications (user_id,notification,status) VALUES ('$user_sender','$message','Unread')");
							if ($notification) {
								echo "Contact Added Successfully";
							}
						}
						else{
							echo "User not found";
						}
						
					}
					else{
						echo "Failure...";
					}
					

				}
				else{
					echo "Failed...";
				}
				
			}
			else{
				echo "Insertion Failed....";
			}
		}
		else{
			echo "You are already added with this contact";
		}
	}
	else{
		echo "First Query Failed";
	}
}


?>