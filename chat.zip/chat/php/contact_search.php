<?php

include('../config/connection.php');

if (isset($_POST['search_key']) && isset($_POST['user'])) {


	$session1=$_POST['user'];
	$search_key=$_POST['search_key'];
	$contacts = array();

	if ($search_key=='' OR $search_key==null) {
		echo "Please enter a string";
	}

	else{
			$select=mysqli_query($db,"SELECT * FROM contacts where user='$session1' or contact='$session1'") or die('Select 1 query failed');
	if ($select) {
		if ($rows=mysqli_num_rows($select)>0) {
			while ($users_data=mysqli_fetch_assoc($select)) {
				if ($users_data['user']==$session1) {
					$contact=$users_data['contact'];
					array_push($contacts, $contact);
				}
				else{
					$user=$users_data['user'];
					array_push($contacts, $user);
				}
			}

			$unique=array_unique($contacts);
			$uniques=implode(",", $unique);
			$select_users=mysqli_query($db,"SELECT * FROM users where user_id IN($uniques) AND (fname LIKE '$search_key%') OR (lname LIKE '$search_key%') OR (mobile LIKE '$search_key%') ORDER BY fname ASC ") or die('Unique users cannot be fetched');
			if ($select) {
			if (mysqli_num_rows($select_users)>0) {
				while($u_users=mysqli_fetch_assoc($select_users)){
					$fname=$u_users['fname'];
					$lname=$u_users['lname'];
					$mobile=$u_users['mobile'];
					$dp=$u_users['dp'];
					$user_id=$u_users['user_id'];



					$display='<div class="media" onclick="load_chat_contact('.$session1.','.$user_id.')">
										<input type="hidden" value='.$user_id.' id="this">
										<img src="'.$dp.'" width="60" height="60" class="">
										<div class="media-body">
											<h5 class="m-1">'.$fname.' '.$lname.'</h5>
											<p class="ml-2">'.$mobile.'</p>
										</div>
									</div><hr>';


					echo $display;
				}
			}
			else{
				echo "No user";
			}
		}
			

		}
		else{
				echo "No Contacts found..";
			}
	}
}
	}



else{
	echo "Something gone wrong";
}



?>
<!--(fname LIKE '$search_key%') OR (lname LIKE '$search_key%') OR (mobile LIKE '$search_key%') ORDER BY fname ASC ")
					