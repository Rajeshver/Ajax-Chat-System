<?php
include('../config/connection.php');

if (isset($_POST['confirm_password']) && isset($_POST['mobile'])) {
	$confirm_password=$_POST['confirm_password'];
	$mobile=$_POST['mobile'];
	$new_password=md5($confirm_password);

	$update=mysqli_query($db,"UPDATE users SET password='$new_password' where mobile='$mobile'");
	if ($update) {
		echo '<p class="alert alert-success">Password Changed Successfully</p>';
	}
	else{
		echo "Failed to update password";
	}
}

?>