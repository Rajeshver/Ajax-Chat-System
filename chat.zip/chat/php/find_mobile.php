<?php
include('../config/connection.php');

if (isset($_POST['mobile'])) {
	$mobile=$_POST['mobile'];
	$display="";

	$select=mysqli_query($db,"SELECT * FROM users where mobile='$mobile'") or die('Query Failed');
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			$data=mysqli_fetch_array($select);
			$display='Is this your account?<br><hr>
			<div class="media">
	<img src="'.$data['dp'].'" width="120" height="120">
	<div class="media-body ml-2" >
		<h4 class="text-info">'.$data['fname'].' '.$data['lname'].'</h4>
		<p class="mt-0">'.$data['mobile'].'</p>
		<input type="hidden" value="'.$data['mobile'].'" id="user_mobile">
		<button class="btn btn-primary" id="myAccount" onclick="verify()">My Account</button>
		<button class="btn btn-warning" id="not_account" onclick="close1()">Not my Account</button>
	</div>
</div>
<hr>

<div class="verify" style="display: none;">
<h4 class="text-info">Change Password</h4>
	<label>New Password</label><br>
	<input type="password" id="new_password" class="form-control" placeholder="New Password"><br>
	<label>Confirm Password</label><br>
	<input type="password" id="confirm_password" class="form-control" placeholder="Confirm Password"><br>
	<small style="display: none;color:red"  id="p_error"></small><br>
	<button class="btn btn-success" id="change_password" onclick="change_password()">Change Password</button>
	<button class="btn btn-warning" id="cancel" onclick="close1()>Cancel</button>

</div>
<hr>


?>

