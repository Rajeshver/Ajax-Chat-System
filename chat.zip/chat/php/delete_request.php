<?php

include('../config/connection.php');
if (isset($_POST['sent_user_id_2']) && isset($_POST['sender_id_2'])) {
	$sender_id=$_POST['sender_id_2'];
	$sent_user_id=$_POST['sent_user_id_2'];

	$select=mysqli_query($db,"SELECT * FROM contact_requests where sender_id='$sender_id' AND user_sent_id='$sent_user_id'") or die("Select query failed ");
	if ($select) {
		if (mysqli_num_rows($select)>0) {
			$delete=mysqli_query($db,"DELETE from contact_requests where sender_id='$sender_id' AND user_sent_id='$sent_user_id'") or die("Delete query failed");
			if ($delete) {
				echo "Request deleted successfully.";
			}
			else{
				echo "Request cannot be deleted";
			}
		}
		else{
			echo "No Request found...First Send Contact Request";
		}
}
}


if (isset($_POST[''])) {
	# code...
}
?>