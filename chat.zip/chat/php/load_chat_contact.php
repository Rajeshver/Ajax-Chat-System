<?php 
include('../config/connection.php');

if (isset($_POST['sender']) && isset($_POST['receiver'])) {
	$sender=$_POST['sender'];
	$receiver=$_POST['receiver'];
	$fname="";
	$lname="";
	$mobile="";
	$dp="";
	$id="";


	$select_info=mysqli_query($db,"SELECT * FROM users where user_id='$receiver'") or die('info query failed');
	if ($select_info) {
		if (mysqli_num_rows($select_info)>0) {
			$info=mysqli_fetch_array($select_info);
			$fname=$info['fname'];
			$lname=$info['lname'];
			$mobile=$info['mobile'];
			$dp=$info['dp'];
			$id=$info['user_id'];

			$select_message=mysqli_query($db,"SELECT * FROM messages where 	sender_id='$sender' AND receiver_id='$receiver'");
			if ($select_message) {
				
						
						$display='<div class="header_contact_info row text-dark">
  <div class="col-sm-5 mt-2">
    <div class="media p-2 ">
    <input type="hidden" name="" value='.$id.' id="receiver_id1" >
       <img src="'.$dp.'" width="60" height="60" class="rounded-circle">
      <div class="media-body ml-3">
       <h4 class="m-0 text-success">'.$fname.' '.$lname.'</h4>
       <p class="mb-0">'.$mobile.'</p>
      </div>
    </div>
  </div>

  <div class="col-sm-1">
    
  </div>
  <div class="col-sm-6">
    <div class="row">
      <div class="col-sm-4 p-3 mt-2 ">
        <a href="tel:+91-'.$mobile.'" title="Start call from mobile" style="font-size: 1.2rem"><i class="fas fa-mobile text-dark"></i></a>
      </div>
      <div class="col-sm-4 p-3 mt-2 ">
          <button onclick="del_chat()" title="Delete Chat" style="font-size: 1.2rem"><i class="fas fa-trash text-dark"></i></button>
      </div>
      <div class="col-sm-4 p-3 mt-2 ">
         <button onclick="block_contact()" title="Block Contact" style="font-size: 1.2rem"><i class="fas fa-ban text-dark"></i></button>
      </div>

    </div>
    
  
   
  </div>
</div>
<hr>
<div class="chat_area1 bg-light p-2" style="height: 450px" id="chat_area1">
   
</div>
<hr>
<div class="row  p-2">
  <div class="col-sm-9">
  <form id="send_message_form">
    <input type="text" name="" id="message_to_sent" placeholder="Start typing your message here..." class="form-control">
  </div>
  </form>
  <div class="col-sm-1">
    <button  title="Send Message" onclick="send_message()"><i class="fas fa-paper-plane btn btn-success" ></i></button>
  </div>
  <div class="col-sm-1">
    <button  title="Send Image" onclick="send_image_modal()"><i class="fas fa-image btn btn-primary"></i></button>
  </div>
</div>
<hr>';
echo $display;


			
		}
	}
	}
}


?>




