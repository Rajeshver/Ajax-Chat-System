<?php
include('config/connection.php');


  
  $sender_id=$_POST['sender_id'];

  $receiver_id=$_POST['rec'];

 $image_name = $_FILES['image_file']['name'];
 $image_tname = $_FILES['image_file']['tmp_name'];
  $destination="stock/";
 if(move_uploaded_file($image_tname,$destination.$image_name)){
 	$image='stock/'.$image_name;
  $image_dimensions=getimagesize($image);
  $image_width=$image_dimensions[0];
  $image_height=$image_dimensions[1];
 
  if ($image_dimensions['mime']=='image/jpeg') {
    $current_image=imagecreatefromjpeg($image);
     $send_data='stock/'.rand().'.jpg';
    $new_image=imagejpeg($current_image,$send_data,30);
    if ($new_image) {
     if (unlink($image)) {
       
       
        $send_data1=$send_data;
        $message_type="image";
        $status="sent";

        $send_message=mysqli_query($db,"INSERT INTO messages (sender_id,receiver_id,message_type,message,status) VALUES ('$sender_id','$receiver_id','$message_type','$send_data1','$status')");
        if ($send_message) {
          echo "Message Sent";
        }
        else{
          echo "Message Not Sent";
        }




     }
     else{
      echo "delte fail";
     }
    }
    else{
      echo "Failed";
    }
  }
  elseif ($image_dimensions['mime']=='image/png') {
    $current_image=imagecreatefrompng($image);
     $send_data= 'stock/'.rand().'.png';
    $new_image=imagejpeg($current_image,$send_data,10);
    if ($new_image) {
     if (unlink($image)) {
      
         $send_data1= $send_data;
        $message_type="image";
        $status="sent";

        $send_message=mysqli_query($db,"INSERT INTO messages (sender_id,receiver_id,message_type,message,status) VALUES ('$sender_id','$receiver_id','$message_type','$send_data1','$status')");
        if ($send_message) {
          echo "Message Sent";
        }
        else{
          echo "Message Not Sent";
        }
     }
     else{
      echo "delte fail";
     }
    }
    else{
      echo "Failed";
    }
  }
}
  
else{
	echo "Fail to upload";
}


?>