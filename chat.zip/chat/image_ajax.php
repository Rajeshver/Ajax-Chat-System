<!DOCTYPE html>
<html>
<head>
	<title>Upload Image AJax</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<form id="upload_form">
			<label>Upload Ajax</label><br>
			<input type="file" name="image_file" id="image_file" onchange="loadfile(event)">
			<img  id="imagetoload" width="300">
			<input type="submit" name="submit" value="Upload Image" id="submit">
		</form>
	</div>
	<script type="text/javascript">
		function loadfile(event) {
      var reader= new FileReader();
      reader.onload=function() {
        var output=document.getElementById('imagetoload');
        output.src=reader.result;
      }
      reader.readAsDataURL(event.target.files[0]);
    }
			$("#upload_form").on("submit",function(e) {
				e.preventDefault();
				var formdata= new FormData(this);

				$.ajax({
					url:"upload.php",
					type:"POST",
					data:formdata,
					contentType:false,
					processData:false,
					success:function(data) {
						alert(data);
					}
				});
			});




	</script>
</body>
</html>