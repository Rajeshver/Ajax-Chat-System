<?php
	session_start();
	session_destroy();
	unset($_SESSION['mobile']);
	$_SESSION['message']="you are now logged out";
	header('location:login.php');

?>