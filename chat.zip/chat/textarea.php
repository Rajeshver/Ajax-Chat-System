<!DOCTYPE html>
<html>
<head>
	<title>textarea</title>
</head>
<body>
			<div class="contact-info1 text-secondary">
					<div class="display-3 text-center mt-5 p-3 border ">
						Click on any user icon to start conversation
					</div>
				</div>

</body>
</html>